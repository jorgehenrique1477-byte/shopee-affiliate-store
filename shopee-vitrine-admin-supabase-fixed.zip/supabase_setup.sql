-- Execute este SQL no Supabase > SQL Editor
create extension if not exists pgcrypto;

create table if not exists site_settings (
  id integer primary key check (id = 1),
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text default '',
  category_id uuid references categories(id) on delete set null,
  price numeric(12,2) not null default 0,
  old_price numeric(12,2) not null default 0,
  image text default '',
  description text default '',
  affiliate_link text not null,
  featured boolean not null default false,
  offer boolean not null default false,
  active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists banners (
  id uuid primary key default gen_random_uuid(),
  title text default '',
  subtitle text default '',
  image text default '',
  link text default '',
  active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists analytics_events (
  id uuid primary key default gen_random_uuid(),
  event_type text not null check (event_type in ('visit','click')),
  product_id uuid references products(id) on delete set null,
  product_name text default '',
  path text default '',
  created_at timestamptz not null default now()
);

alter table site_settings enable row level security;
alter table categories enable row level security;
alter table products enable row level security;
alter table banners enable row level security;
alter table analytics_events enable row level security;

-- Leitura pública apenas do que a vitrine precisa.
drop policy if exists public_read_settings on site_settings;
create policy public_read_settings on site_settings for select to anon, authenticated using (true);

drop policy if exists public_read_categories on categories;
create policy public_read_categories on categories for select to anon, authenticated using (active = true or auth.uid() is not null);

drop policy if exists public_read_products on products;
create policy public_read_products on products for select to anon, authenticated using (active = true or auth.uid() is not null);

drop policy if exists public_read_banners on banners;
create policy public_read_banners on banners for select to anon, authenticated using (active = true or auth.uid() is not null);

-- Ações administrativas somente para usuário autenticado.
create policy auth_all_settings on site_settings for all to authenticated using (true) with check (true);
create policy auth_all_categories on categories for all to authenticated using (true) with check (true);
create policy auth_all_products on products for all to authenticated using (true) with check (true);
create policy auth_all_banners on banners for all to authenticated using (true) with check (true);

-- A vitrine pode registrar visitas/cliques, mas não pode ler analytics como visitante.
drop policy if exists public_insert_analytics on analytics_events;
create policy public_insert_analytics on analytics_events for insert to anon, authenticated with check (true);
create policy auth_read_analytics on analytics_events for select to authenticated using (true);

insert into site_settings(id,data) values (1, '{"siteName":"Ofertas Premium Shopee","description":"As melhores ofertas selecionadas e verificadas para você economizar.","buttonText":"Ver na Shopee","footerText":"© 2026 Ofertas Premium. Todos os direitos reservados.","primaryColor":"#ee4d2d","logo":""}'::jsonb) on conflict (id) do nothing;

insert into categories(name,sort_order)
select x.name,x.ord from (values ('Eletrônicos',0),('Casa',1),('Moda',2),('Beleza',3)) x(name,ord)
where not exists (select 1 from categories);

insert into banners(title,subtitle,image,link,sort_order)
select 'Super Ofertas do Dia','Até 70% de desconto em produtos selecionados na Shopee','https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=1200&q=80','https://shopee.com.br',0
where not exists (select 1 from banners);
